module.exports = '/home/pi/Desktop/MetaWear-SDK-Cpp/dist/release/lib/arm/libmetawear.so.0.20.0';
