#include "dfu_utility.h"

int  MBL_PACKETS_NOTIFICATION_INTERVAL = 10;
int const MBL_PACKET_SIZE = 20;
