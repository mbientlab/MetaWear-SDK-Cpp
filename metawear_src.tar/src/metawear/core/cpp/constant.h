#pragma once

#include <stdint.h>

const uint8_t MW_CMD_MAX_LENGTH= 18, BLE_PACKET_SIZE = MW_CMD_MAX_LENGTH + 2;
