#pragma once

enum class SwitchRegister : uint8_t {
    STATE = 1
};

