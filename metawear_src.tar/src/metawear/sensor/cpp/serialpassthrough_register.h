#pragma once

enum class SerialPassthroughRegister : uint8_t {
    I2C_READ_WRITE= 1,
    SPI_READ_WRITE,
};
