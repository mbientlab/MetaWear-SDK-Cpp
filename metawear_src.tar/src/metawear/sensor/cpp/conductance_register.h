#pragma once

enum class ConductanceRegister : uint8_t {
    CONDUCTANCE = 1,
    CALIBRATE,
    MODE
};
