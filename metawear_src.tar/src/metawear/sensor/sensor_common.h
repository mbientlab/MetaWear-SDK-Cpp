#include <stdint.h>

#include "metawear/core/datasignal_fwd.h"
#include "metawear/core/metawearboard_fwd.h"
#include "metawear/platform/dllmarker.h"
